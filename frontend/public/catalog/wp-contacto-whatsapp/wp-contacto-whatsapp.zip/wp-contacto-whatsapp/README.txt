Plugin WordPress: contacto por WhatsApp

Instalación: sube el ZIP desde Plugins > Añadir nuevo > Subir plugin, actívalo e inserta el shortcode en una página.

Ejemplo:
[ciem_whatsapp numero="51999989709" texto="Contactar" mensaje="Hola"]

Valida en una instalación de pruebas antes de producción. No se han realizado pruebas de integración en WordPress. Sin panel de configuración, servicios externos ni soporte incluido.
Licencia MIT.
