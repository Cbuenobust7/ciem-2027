Plugin WordPress: aviso destacado

Instalación: sube el ZIP desde Plugins > Añadir nuevo > Subir plugin, actívalo e inserta el shortcode en una página.

Ejemplo:
[ciem_aviso texto="Escribe tu anuncio" url="https://example.com" enlace="Ver detalle"]

Valida en una instalación de pruebas antes de producción. No se han realizado pruebas de integración en WordPress. Sin panel de configuración, servicios externos ni soporte incluido.
Licencia MIT.
