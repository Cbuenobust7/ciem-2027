Plugin WordPress: preguntas frecuentes

Instalación: sube el ZIP desde Plugins > Añadir nuevo > Subir plugin, actívalo e inserta el shortcode en una página.

Ejemplo:
[ciem_faq pregunta="¿Cómo contacto?" respuesta="Escribe aquí tu respuesta."]

Valida en una instalación de pruebas antes de producción. No se han realizado pruebas de integración en WordPress. Sin panel de configuración, servicios externos ni soporte incluido.
Licencia MIT.
