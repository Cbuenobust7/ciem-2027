Componente: panel de indicadores

Abre index.html en tu navegador y edita el HTML/CSS. Sin dependencias ni compilación. Sustituye datos, precios, correos y textos de ejemplo antes de publicar. No incluye backend, pagos, cuentas ni integración con servicios. Personalización y hosting se cotizan aparte.
Licencia MIT.
